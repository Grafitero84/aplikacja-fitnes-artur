import 'package:flutter/material.dart';

void main() => runApp(TwojaFormaApp());

class TwojaFormaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Twoja forma',
      theme: ThemeData(primarySwatch: Colors.green),
      home: Scaffold(
        appBar: AppBar(title: Text('Twoja forma')),
        body: Center(child: Text('Witaj w Twojej formie!')),
      ),
    );
  }
}
