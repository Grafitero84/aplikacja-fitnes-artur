import 'package:flutter/material.dart';

void main() => runApp(FitnessApp());

class FitnessApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trening i Jadłospis',
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final jadlospis = [
    'Śniadanie: Płatki owsiane + banan + mleko',
    'Lunch: Makaron + tuńczyk + serek wiejski',
    'Obiad: Kotlety z piersi kurczaka + pieczywo + jajko',
    'Kolacja: Twaróg + szynka + pieczywo'
  ];

  final trening = [
    'Dzień 1: Górna partia ciała – hantle, pompki, gumy',
    'Dzień 2: Dolna partia ciała – przysiady, wykroki',
    'Dzień 3: Całe ciało – pompki, deska, wiosłowanie',
    'Dzień 4: Obwód – wszystkie grupy + brzuch'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Plan Treningowy i Jadłospis')),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text('🧠 Plan Treningowy', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ...trening.map((e) => ListTile(title: Text(e))),
          SizedBox(height: 20),
          Text('🍽️ Jadłospis', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ...jadlospis.map((e) => ListTile(title: Text(e))),
        ],
      ),
    );
  }
}